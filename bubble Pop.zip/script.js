

function audioPlay(){
     const audio= new Audio('bubble Pop.mp3');
     audio.play();
}